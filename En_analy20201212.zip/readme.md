# 联系项目

# 命令

1. 安装

```
yarn
```
2. 运行开发环境

```
yarn start
```

3. 输出测试环境

```
yarn test
```

4. 输出生产环境

```
yarn build
```
5. 安装插件
yarn add ...
6. 删除大文件夹命令

```
rimraf node_modules
```