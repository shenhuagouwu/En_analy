'use strict';
module.exports = {
    NODE_ENV: "development",
    BASE_API:"/api"
};