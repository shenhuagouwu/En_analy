'use strict';
module.exports = {
    NODE_ENV: "production",
    BASE_API:"http://172.16.0.121:807/index.php/"
};