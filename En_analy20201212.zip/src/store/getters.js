const getters = {
    editorType: state => state.leftnav.editorType,
    dataName: state => state.printdata.dataName,
    userInfo: state => state.user.userInfo,
};
export default getters;