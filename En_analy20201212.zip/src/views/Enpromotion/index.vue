<template>
  <router-view />
</template>
<script>
export default {
    name: 'EnpromotionPage'
}
</script>

<style scoped>
    .list {
    font-size: 100px;
    color: red;
    line-height: 1;
    }
</style>
