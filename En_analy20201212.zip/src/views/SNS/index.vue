<template>
  <router-view />
</template>

<script>
export default {
    name: 'SNSPage'
}
</script>

<style scoped>

</style>
